import { AppService } from './app.service';
import { AfterViewInit, Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { Observable, Subject } from 'rxjs';
import { debounceTime, distinctUntilChanged, map } from 'rxjs/operators';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent implements OnInit {
  title = 'rxjsdemo';
  data :Observable<any> = this.appService.getData();

  allConsoleMessages: string[] = [];
  userInput: string = "";
  userInputUpdate = new Subject<string>();
  constructor(private appService:AppService){
     // Debounce search.
     this.userInputUpdate.pipe(
      debounceTime(400),
      distinctUntilChanged())
      .subscribe(value => {
        this.allConsoleMessages.push(value);
      });
  }

  ngOnInit(): void {
    
  }

}
